#!/usr/bin/env python3.5

#"Good Deal Poker Engine" Version 0.05 is a library built to manage the logic of dealing and evaluating hands of poker, is currently in beta, and is distributed under
#version 3 of the General Public Use License. See the COPYING file distributed with this file to read the terms of distribution
#Copyright (C) 2016 Stephen C. Hostetler

#Random shuffle shuffles values in strings and lists
from random import shuffle
#Sets a bool toggle defaulted to False. True when this lib is imported and used together with a gui or othe logic lib 
testMode = False
#defines a class for creating a new hand of cards
class Hand():
    #defines a main function for the current class and automaticly initates it(passes in cardValues: string values for each card in the current hand. example: AS = Ace of Spades)
    def __init__(self, cardValues):
        #self.cardValues = ['', '', '', '', ''] #Uncomment this line, enter string values for cards, and comment out the line below to test hand evaluations.
        #list stores string values for each card(sets the place holder string for the current hand equql to the values cardValues)
        self.cardValues = cardValues
        #Creates an empty list for resorting the cards in the deck by rank
        self.ordered = []
        #Creates an empty list for file name strings
        self.filenames = []
        #Creates an empty list for cards marked for discard
        self.marked = []
        #Creates a placeholder list for counting how many of each rank exists in each hand and sets each placeholder value to 0
        self.numberOfRanks = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        #Creates a placeholder list for determaning which suits exist in hand
        self.suits = []
        #Creates a placeholder string to hold the rank of the high card in the current hand is (Ace, King, Queen, ect...)
        self.highCard = ''
        #Creates a placeholder string to hold the type of hand the current hand is (pair, two pair, three of a kind, etc...)
        self.type = ''
        #Creates a placeholder integar to hold the number of pairs in the current hand
        self.numberOfPairs = 0
        #Creates a placeholder for the card rank of full in case of a fullhouse.
        self.full = ''
        #Creates a placeholder bool to determine if there is three of a kind in the current deck
        self.threeOfAKind = False
        #Creates a placeholder bool to determine if there is a straight in the current deck
        self.straight = False
        #Creates an integar to store an itteration count of how many cards away from a straight the current hand is. Example: if the hand type is a straight, straightCount = 5
        self.straightCount = 0
        #Creates a placeholder bool to determine if there is a flush in the current hand
        self.flush = False
        #Creates a placeholder bool to determine if there is a straight flush in the current hand
        self.straightFlush = False
        #Creates a placeholder integar to hold the number of suits in the current hand
        self.numberOfSuits = 0
#Passes in the current hand defined in deal and evaluates the current hand to determine its type
def evaluate(hand):
    #Creates a list of all possible card rank values in ascending order
    rank = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
    #Creates a list of all possible card suits
    suit = ['H', 'D', 'C', 'S']
    #Removes old values from the current hands ordered list of string values for each card, so that the list will be empty when the cards need to be reordered after discard
    del hand.ordered[0:4]
    #Sets rank index to 0 so that the following loop will start at the 0th element of the list of possible card ranks
    rankIndex = 0
    #Loops through all possible card ranks
    for ranks in rank:
        #Loops through all of the cards in hand
        for cards in hand.cardValues:
            #returns true if the last character (The suit of the current card does not exist in the current hands suits list)
            if cards[-1] not in hand.suits:
                #Adds the suit of the current card to the current hand's suit list, if it isn't already in the list 
                hand.suits.append(cards[-1])
            #Counts the number of items in the current hand's suit list, and sets the current hand's number of suits intager equal to the count(counts the suits in the hand)
            hand.numberOfSuits = len(hand.suits)
            #Checks if the current rank in the loop exists as a substring of the current card's string value
            if ranks in cards:
                #if the condition is true, the current card is appended to the current hand's ordered list(This sorts the cards by rank)
                hand.ordered.append(cards)
                hand.filenames.append(cards + '.png')
                #If the condition is true, one is added to the rank count for the corrosponding rank, producing a count of the number of cards the hand with that rank.
                hand.numberOfRanks[rankIndex] += 1
        #adds one to the rank index(moves the loop to the next rank to be counted)
        rankIndex += 1
    #sets the current hand's high card value to the value of the last card in the hand's rank, or the 1st character of the last card in the hand 
    hand.highCard = str(hand.ordered[4][0])
    #Prevents high card value from being set to 0(if 10 is the high card, it has an extra diget. This checks the last card value to see if it contains 10, if so, the high card is set to 10) 
    if '10' in str(hand.ordered[4]): hand.highCard = '10'
    #sets the current hand's high card to 'Ace' if the high card is currently 'A', so that the hand type string reads '... with a high card of Ace,' not '... with a high card of A'
    if hand.highCard == 'A': hand.highCard = 'Ace'
    #sets the current hand's high card to 'Jack' if the high card is currently 'J', so that the hand type string reads '... with a high card of Jack,' not '... with a high card of J'
    if hand.highCard == 'J': hand.highCard = 'Jack'
    #sets the current hand's high card to 'Queen' if the high card is currently 'Q', so that the hand type string reads '... with a high card of Queen,' not '... with a high card of Q'
    if hand.highCard == 'Q': hand.highCard = 'Queen'
     #sets the current hand's high card to 'King' if the high card is currently 'K', so that the hand type string reads '... with a high card of King,' not '... with a high card of K'
    if hand.highCard == 'K': hand.highCard = 'King'
    #index for current loop. starts at 2 because Ace == 1 (Itter for ranks)
    ranksIndex = 2
    #Place holder for substring in type for groups of ranks in the current hand. (i.e. Pairs, 3 of a kind etc...)
    cardSet = ''
    #loops through list of rank counts in the current hand.
    for items in hand.numberOfRanks:
        #if the current item in loop is > 1, store the current rank as a string in cardSet 
        if items > 1: cardSet = str(ranksIndex)

        #These if statments check for card ranks that are face cards by first checking for their numbered rank, then assigning the name of the face card to cardSet if it exists.
        
        if cardSet == '11': cardSet ='Jack'
        if cardSet == '12': cardSet ='Queen'
        if cardSet == '13': cardSet ='King'
        if cardSet == '14': cardSet ='Ace'

        #Checks if the current rank in the loop has 1 card with that value in the current hand. If there is exactly one card in the current hand with the current rank,
        #A stright is possible and 1 is added to straight count, otherwise, the count is reset at 0

        if items == 1: hand.straightCount += 1
        else: hand.straightCount = 0

        #Checks for type in the current hand and builds output for current hand evaluation from substrings. Moves Ace to the end of the rank order if it is the high card.
        if items == 2:
            hand.numberOfPairs += 1
            if hand.numberOfPairs == 1:
                hand.type = 'You have a pair of ' + cardSet + "'s " + 'with '+ hand.highCard + ' high.'
        if hand.numberOfPairs == 2:
            hand.type = 'You have two pair. your highist pair is a pair of ' + cardSet + "'s " + 'with '+ hand.highCard + ' high.'
        if items == 3:
            hand.threeOfAKind = True
            hand.full = cardSet
            hand.type = 'three of a kind of ' + cardSet + "'s " + 'with '+ hand.highCard + ' high.'  
        if hand.threeOfAKind == True and hand.numberOfPairs == 1:
            hand.type = 'You have a full house ' + 'with '+ hand.highCard + ' high and ' + hand.full + "'s full."
        if items == 4:
            hand.type = 'You have four of a kind of ' + cardSet + "'s " + 'with '+ hand.highCard + ' high.'
        if hand.straightCount == 5 or hand.straightCount == 4 and '10' in hand.ordered and hand.highCard == 'Ace':
            hand.straight = True
            if '5' in hand.ordered[4]:
                hand.highCard = '5'
                moveAce = hand.ordered[-1]
                del hand.ordered[-1]
                hand.ordered.insert(0, moveAce)
            hand.type = 'You have a straight ' + 'with '+ hand.highCard + ' high.'
        if hand.numberOfSuits == 1:
            hand.flush = True
            hand.type = 'You have a flush ' + 'with '+ hand.highCard + ' high'
        if hand.straight is True and hand.flush == True:
            hand.type = 'You have a straight flush ' + 'with '+ hand.highCard + ' high.'
            hand.straightFlush = True
        if hand.highCard == 'Ace' and hand.straightFlush == True:
            hand.type = 'You have a royal flush!'
        if hand.type == '':
            hand.type = 'You have ' + hand.highCard + ' high.'
        ranksIndex += 1

    #Prints hand with evaluation if lib is in test mode.
    if testMode == True:
        print('Hand evaluation: ' + hand.type)
        print('Hand: ' + str(hand.ordered) + '\n')
    return(hand.type, hand.ordered)
#Defines a function to discard
def discard(hand, deck):
    #Defines text string for input prompt
    discardText = 'Which cards would you like to discard?'
    #Sets testMode to true because the current function will only be called if this lib is not imported into a larger project
    if testMode == True:
            print('(Enter a number for each card you want to discard 1-5 seperated by a space and press return.)')
            print(discardText)
            #Splits user input into a list called marked
            hand.marked = list(map(int,input().split()))
    for items in hand.marked:
        hand.ordered[items - 1] = deck[0]
        del deck[0]
    hand = Hand(hand.ordered)
    evaluate(hand)
#deal is the library's main function. When called it builds a deck from all possible suit and rank values, shuffles the deck, builds a hand from the
#deck, evaluates the hand, and evaluates the results
def deal():
    #Builds a list with a string value for each card in a standard deck of cards
    deck = ['2H', '2D', '2C', '2S', '3H', '3D', '3C', '3S','4H', '4D', '4C', '4S', '5H', '5D', '5C', '5S','6H', '6D', '6C', '6S', '7H', '7D', '7C', '7S',
        '8H','8D','8C','8S','9H', '9D', '9C', '9S', '10H', '10D', '10C', '10S', 'JH', 'JD', 'JC', 'JS', 'QH', 'QD', 'QC', 'QS', 'KH', 'KD', 'KC', 'KS', 'AH', 'AD', 'AC', 'AS']
    #shuffels the deck values
    shuffle(deck)
    #Creates a list which holds a copy of the first five values of deck, or cards values for the current hand (Example: 'AS' = Ace of Spades)
    cardValues = deck[0:5]
    #Creates an instance of Hand named hand
    hand = Hand(cardValues)
    #Removes the first five values or cards from deck
    del deck[0:5]
    #Calls the function evaluate, and passes in hand to determine the hand type
    evaluate(hand)
    #Calls function for discarding unwanted cards in the current hand. Passes in the current hand and the deck minus the current hand.
    discard(hand, deck)
    #Checks if this lib is imported as part of a larger program.
    if testMode == False:
        #Returns the current deck.
        return(hand, deck)
#Returns True if this lib is imported as part of a larger program.
if __name__ == "__main__":
    #Stores result of if statment as a bool for ease of use.
    testMode = True
    #If testMode == True, prints info about this lib.
    print('Good Deal Poker Engine Version 0.05 Beta, is currently running in test mode, and is subject to the terms and conditions of version 3 of the General Public Use License.\n' + 'Copyright (C) 2016 Stephen C. Hostetler.\n')
    #calls deal function.
    deal()
    
    
    
    
        
